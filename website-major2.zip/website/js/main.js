(function () {
    $(document).ready(function () {
        userController.init(configConstants);
        uploadController.init(configConstants);
    });
}());
