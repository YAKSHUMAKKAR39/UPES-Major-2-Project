var configConstants = {
    auth0: {
        domain: 'dev-sfjuovxx86dajb26.us.auth0.com',
        clientId: 'UQ0119M47TV0Nibmr98bKPT2KzKDbnKI'
    },
    apiBaseUrl: 'https://acgch0s7z0.execute-api.us-east-1.amazonaws.com/dev'
};