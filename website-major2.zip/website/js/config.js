var configConstants = {
    auth0: {
        domain: 'dev-sfjuovxx86dajb26.us.auth0.com',
        clientId: 'UQ0119M47TV0Nibmr98bKPT2KzKDbnKI'
    }
};